module.exports=[83601,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},72669,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(83601).default,width:256,height:256}}];

//# sourceMappingURL=Desktop_DELV%20LANDING%20PAGE_delv-landing_src_app_f2874188._.js.map