var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__98c25886._.js")
R.c("server/chunks/b65c1_next_dist_269d852b._.js")
R.c("server/chunks/[root-of-the-server]__25fa2aa3._.js")
R.c("server/chunks/b65c1_next_dist_97011823._.js")
R.m(5180)
R.m(89201)
module.exports=R.m(89201).exports
