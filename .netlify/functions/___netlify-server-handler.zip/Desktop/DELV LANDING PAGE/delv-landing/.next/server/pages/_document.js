var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__1f179436._.js")
R.c("server/chunks/ssr/[root-of-the-server]__8f7e80a7._.js")
R.m(95764)
module.exports=R.m(95764).exports
