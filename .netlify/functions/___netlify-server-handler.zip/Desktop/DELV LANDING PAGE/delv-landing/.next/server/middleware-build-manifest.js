globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/5eeff4852eae0790.js",
      "static/chunks/8a6a4f3751845549.js",
      "static/chunks/turbopack-72b083b7aea09acb.js"
    ],
    "/_error": [
      "static/chunks/af3ef983cc50b59a.js",
      "static/chunks/8a6a4f3751845549.js",
      "static/chunks/turbopack-d10c10be88716d58.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/dc95e3925a7400c9.js",
    "static/chunks/2641911866a8a62b.js",
    "static/chunks/6941bb9d1ff5c276.js",
    "static/chunks/1623919f630230bf.js",
    "static/chunks/turbopack-8d4e661d9c853204.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];